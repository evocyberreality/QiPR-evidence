# Complete cold-start reproduction

Execution ID: `reproduction_cold_20261021T132500Z`

This archive contains a new reproduction of the 48 local audit-simulator configurations. It is not a new IBM QPU execution and does not replace the original historical archive.

Policy: cold start, cache disabled, no warmup, one independent worker process per run, no silent retries. The exact environment is in `COLD_START_CHECKLIST.json`.

Every run has its input, output, `certificate_start.json`, `certificate_end.json`, and a corresponding start/finish record in `evidence/attempts.jsonl`. Only the public Ed25519 key is included; the private signing key remains outside the publication tree.

The runner records a compatibility profile: the historical benchmark selected one member from a stable SET. The current directional core requires whole authorization, so the reproduction runner explicitly shims that authorization guard; this is disclosed and is not a claim of byte-identical current-core execution.
